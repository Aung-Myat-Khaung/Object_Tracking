COLORS = {
    'green': {
        "lower": (25, 50, 50),
        "higher": (80, 255, 255)
    }
}

CANNY_HIGH = 130
CANNY_LOW = 100

MAX_MISSES = 50
MAX_DISTANCE = 300
MIN_AREA = 300
FRAME_SIZE = (640,480)

HEIGHT = 480
WIDTH = 640